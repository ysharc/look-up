# look-up
Dictionary look up for highlighted words
